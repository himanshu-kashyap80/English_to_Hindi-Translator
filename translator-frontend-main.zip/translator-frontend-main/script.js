const dictionary = {
  "hello": "नमस्ते",
  "how are you": "आप कैसे हैं",
  "thank you": "धन्यवाद",
  "good morning": "सुप्रभात",
  "good night": "शुभ रात्रि",
  "what is your name": "आपका नाम क्या है",
  "my name is": "मेरा नाम है",
  "i love you": "मैं तुमसे प्यार करता हूँ",
  "where are you": "तुम कहाँ हो",
  "yes": "हाँ",
  "no": "नहीं",
  "please": "कृपया",
  "sorry": "माफ़ कीजिए",
  "i am fine": "मैं ठीक हूँ"
};

async function translateText() {
  const input = document.getElementById("inputText").value.trim();
  const output = document.getElementById("outputText");
  
  if (!input) {
    output.innerHTML = "❌ Please enter some text to translate";
    output.style.backgroundColor = "#f8d7da";
    return;
  }

  try {
    const response = await fetch('https://translator-backend-xi.vercel.app/translate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'accept': 'application/json'
      },
      body: JSON.stringify({ text: input })
    });

    if (!response.ok) {
      throw new Error('Translation failed');
    }

    const data = await response.json();
    output.innerHTML = `✅ <strong>${data.translation}</strong>`;
    output.style.backgroundColor = "#d4edda";
  } catch (error) {
    // Fallback to local dictionary if API fails
    const lowerInput = input.toLowerCase();
    if (dictionary[lowerInput]) {
      output.innerHTML = `✅ <strong>${dictionary[lowerInput]}</strong>`;
      output.style.backgroundColor = "#d4edda";
    } else {
      output.innerHTML = "❌ Translation not found. Try a simple phrase like 'hello' or 'thank you'.";
      output.style.backgroundColor = "#f8d7da";
    }
  }
}

function clearText() {
  document.getElementById("inputText").value = "";
  document.getElementById("outputText").innerHTML = "Translation will appear here...";
  document.getElementById("outputText").style.backgroundColor = "#ffffff";
}

function showExample() {
  const examples = [
    "hello",
    "thank you",
    "good morning",
    "what is your name",
    "i love you"
  ];
  const random = examples[Math.floor(Math.random() * examples.length)];
  document.getElementById("inputText").value = random;
} 